package money.util;

public class cls_MONEY_Constant {

}
